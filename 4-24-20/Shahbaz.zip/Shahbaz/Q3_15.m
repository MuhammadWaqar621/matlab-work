% 3.15
clc
clear all 
close all
thermocoubple1=[84.3;86.4;85.2;87.1;83.5;84.8;85;85.3;85.3;85.2;82.3;84.7;83.6];
thermocoubple2=[90;89.5;88.6;88.9;88.9;90.4;89.3;89.5;88.9;89.1;89.5;89.4;89.8];
thermocoubple3=[86.7;87.6;88.3;85.3;80.3;82.4;83.4;85.4;86.3;85.3;89.0;87.3;87.2];
data=[thermocoubple1 thermocoubple2 thermocoubple3]
min_thermocoubple1=min(thermocoubple1)
max_thermocoubple1=max(thermocoubple1)
min_thermocoubple2=min(thermocoubple2)
max_thermocoubple2=max(thermocoubple2)
min_thermocoubple3=min(thermocoubple3)
max_thermocoubple3=max(thermocoubple3)