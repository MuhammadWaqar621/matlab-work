% Q5.5
clc
clear all
close all
x=-pi:pi/100:pi;
y1=sin(x);
y2=sin(2*x);
y3=sin(3*x);
plot(x,y1,'--','color','r')
hold on 
plot(x,y2,'-','color','b')
hold on 
plot(x,y3,':','color','g')
hold on 
xlabel('x')
ylabel('Sin Values')
title('sin plot')
grid on
legend('sin(x)','sin(2x)','sin(3x)')
xlim([-6 6])
text(-5.8,.8,'sin plot for -pi to pi')