% Q4.6
clc
clear all
close all
base= linspace(0,10, 5)
height= linspace(2,6,5)
[X,Y]=meshgrid(base,height);
area=(X.*Y)/2