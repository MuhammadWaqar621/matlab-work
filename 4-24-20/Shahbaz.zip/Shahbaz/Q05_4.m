% Q5.4
clc
clear all
close all
x=-pi:pi/100:pi;
y1=sin(x);
y2=sin(2*x);
y3=sin(3*x);
plot(x,y1,'--','color','r')
hold on 
plot(x,y2,'-','color','b')
hold on 
plot(x,y3,':','color','g')
hold on 
xlabel('x')
ylabel('Sin Values')
title('sin plot')
grid on