%Q6.6
clc
clear 
close
diameter_moon=4217;
diameter_earth=7926;
r_E=diameter_earth/2;
r_M=diameter_moon/2;
h=0:100:10000;
disp('distance for moon ')
d=distance(r_M,h);
d'
disp('distance for earth ')
d=distance(r_E,h);
d'