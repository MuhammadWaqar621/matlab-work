% Q5.3
clc
clear all
close all
x=-pi:pi/100:pi;
y1=sin(x);
y2=sin(2*x);
y3=sin(3*x);
plot(x,y1,x,y2,x,y3)
xlabel('x')
ylabel('Sin Values')
title('sin plot')
grid on