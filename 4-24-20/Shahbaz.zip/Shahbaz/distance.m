function [d]=distance(r,h)
% 6.6_a
[R,H]=meshgrid(r,h);
d=sqrt(2.*R.*H + H.^2);
end 
