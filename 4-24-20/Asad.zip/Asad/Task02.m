% Task02
clc
clear 
a=57.32;
b=56.32;
c=-21;
d=21^2;
e=31.5;
f=98.7;
g=a*c + (d*b^2 + f)/d