function [] = MohammedExercise5()
clc, clear
x = code1();
y = code2();
z = code3();
% Output

fprintf('\nResult 1:\n')
fprintf('%4.0f',x)
fprintf('\nResult 2:\n')
fprintf('%4.0f',y)
fprintf('\n\nResult 3:\n')
fprintf('%5.1f',z(1),z(2),z(3))
fprintf('\n')
fprintf('%5.1f',z(4),z(5),z(6))
fprintf('\n')
fprintf('%5.1f',z(7),z(8),z(9))
fprintf('\n\n')
fprintf('   x     y     z  \n')
data = [x;y;z];
fprintf('%4.0f %5.0f %6.1f \n', data)
fprintf('\n')
end
%Code 1 
function result1 = code1()
clc,clear
a = [1:9];
for i = 1:5 
    a(i) = 2 + a(i) + a(i+1);  
end
result1 = a;
end

%Code 2
function result2 = code2()
clc,clear
k = 1;
a(1) = 1;
while k <= 8
    k = k + 2;
    if k == 3
        a(k) = a(1) + 1;
    else
        a(k) = 1;
    end
end
result2 = a;
end

%Code 3 

function result3 = code3()
   result3 = rand(1,9);
   figure(1)
   imagesc(rand(8));
   axis equal
   figure(2)
   surf(5*rand(8));
   view(20,20)
   
end