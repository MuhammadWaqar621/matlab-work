clc,clear
k = 1;
a(1) = 1;
while k <= 5
    k = k + 2;
    if k == 3
        a(k) = a(1) + 1;
    else
        a(k) = 1;
    end
end
disp(a)