clc,clear 
a = [1:6];
for i = 1:5 
    a(i) = 2 + a(i) + a(i+1);  
end
disp(a)
