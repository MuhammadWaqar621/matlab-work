
function [] = MohammedExercise4()
clc
clear 
result1 = code1(); 
disp('Result 1: ')
disp(result1)
result2 = code2();
disp('Result 2: ')
disp(result2)
end 
%Code 1
function result1 = code1()
clear
a = [1:6];
for i = 1:5 
    a(i) = 2 + a(i) + a(i+1);  
end
result1 = a;

end


%Code 2
function result2 = code2()
clear
k = 1;
a(1) = 1;
while k <= 5
    k = k + 2;
    if k == 3
        a(k) = a(1) + 1;
    else
        a(k) = 1;
    end
end
result2 = a;
end



