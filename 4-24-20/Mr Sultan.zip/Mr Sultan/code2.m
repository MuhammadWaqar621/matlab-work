function a = Sfunc2()
%%%%%%%%%%Code2%%%%%%%%%%%
k = 1;
a(1) = 1;%initializing a
while k <= 5 %%%%%%while loop
k = k + 2;
if k == 3 %condition operator
a(k) = a(1) + 1;
else
a(k) = 1;
end
end

end

