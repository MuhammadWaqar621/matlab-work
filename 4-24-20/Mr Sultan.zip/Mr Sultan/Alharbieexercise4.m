%%%%%%%%%%Main function%%%%%%%
clc % Clear the command window
clear all %clears all the variables
close all  %close all the windows open in matlab currently

%%%%%%%Subfunctions calling%%%%%%%
a=code1();%subfunction1 with no argument
disp(a) %display code1 output

a=code2();% sub function 2 with no argument
disp(a) %display code2 output

