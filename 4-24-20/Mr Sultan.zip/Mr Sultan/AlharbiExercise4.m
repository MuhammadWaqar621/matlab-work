% Exercise 4 : use of functions
function [] = AlharbiExercise4()

clc, clear
%call function 
code1result = code1(); 
disp('Code 1 Output is: ')
disp(code1result)
code2result = code2();

disp('Code 2 Output is: ')
disp(code2result)
end 
%Code 1 subfunction
function result1 = code1()
a = [1:6]; % defining array
for i = 1:5  %for loop
a(i) = 2 + a(i) + a(i+1); %computing a
end
result1 = a;
end


%Code 2 subfunction
function result2 = code2()
clear all
k = 1; 
a(1) = 1;
while k <= 5
    k = k + 2;
    if k == 3 %condition operator
      
        a(k) = a(1) + 1;
    else 
        a(k) = 1;
    end
end
result2 = a;
end



