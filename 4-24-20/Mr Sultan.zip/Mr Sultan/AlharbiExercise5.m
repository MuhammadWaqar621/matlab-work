
function [] = AlharbiExercise5()
clc
clear all
close all
a = code1();
b = code2();
c = code3();

% Output
fprintf('\nCode1 results\n')
fprintf('%4.0f',a)
fprintf('\n\nCode2 result\n')
fprintf('%4.0f',b)
fprintf('\n\nCode3 results in matrix\n')
fprintf('%5.1f',c(1),c(2),c(3))
fprintf('\n')
fprintf('%5.1f',c(4),c(5),c(6))
fprintf('\n')
fprintf('%5.1f',c(7),c(8),c(9))
fprintf('\n\n')
fprintf('   a     b     c  \n')
data = [a;b;c];
fprintf('%4.0f %5.0f %6.1f \n', data)
fprintf('\n')

end


%Code 1 subfunction

function result1 = code1()
clc,clear
a = [1:9];
for i = 1:5 
    a(i) = 2 + a(i) + a(i+1);  
end
result1 = a;
end

%Code 2 

function result2 = code2()
clc,clear
k = 1;
a(1) = 1;
while k <= 8
    k = k + 2;
    if k == 3 
        a(k) = a(1) + 1;
    else
        a(k) = 1; 
    end
end
result2 = a;
end

%Code 3

function result3 = code3()
   result3 = rand(1,9);
   figure(1)
   imagesc(rand(8));
   axis equal
   figure(2)
   surf(5*rand(8));
   view(20,20)
end