function a = Sfunc1()
%%%%%%%code1%%%%%%%%%
a = [1:6]; % defining array
for i = 1:5  %for loop
a(i) = 2 + a(i) + a(i+1); %computing a
end

end

